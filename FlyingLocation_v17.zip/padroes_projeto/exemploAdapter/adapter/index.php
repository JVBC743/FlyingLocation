<?php

    require_once ('classes/Adapter.php');
    use padroes_projeto\exemploAdapter\adapter\classes\Adapter;

    $adapter = new Adapter();
    $adapter->metodo1();

?>