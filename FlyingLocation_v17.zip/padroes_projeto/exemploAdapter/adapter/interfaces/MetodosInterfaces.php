<?php

    declare(strict_types=1);
    

    namespace padroes_projeto\exemploAdapter\adapter\interfaces;

    interface MetodosInterfaces{

        public function metodo1();
        public function metodo2($name);
    }
?>