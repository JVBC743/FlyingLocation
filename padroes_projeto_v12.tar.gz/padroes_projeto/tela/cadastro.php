<?php
    session_start();
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
    require("../Adaptador/BDAcesso.php");// Dessa forma está correta.
    use padroes_projeto\Adaptador\BDAcesso;
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="../assets/bootstrap-5.3.3-dist/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/login_register.css">
</head>
<body>
    
<div class="container">
    <div class="system-name-register">
        <p>Flying
            <span><br>Location</span></p>
    </div>
    <form action = "<?php echo $_SERVER["PHP_SELF"];?>" method = "post">
        <div class="register">
            <label class="form-label">Nome de Usuário</label>
            <input class="form-control" name = "nome_cadastro" type="text" placeholder="Username">
            <label class="form-label">CEP</label>
            <input class="form-control" name = "cep_cadastro" type="text" placeholder="10000787">
            <label class="form-label">E-mail</label>
            <input class="form-control" name = "email" type="email" placeholder="exemple@exemple.com">
            <label class="form-label">N° Casa</label>
            <input class="form-control" name = "numeracao_casa" type="number" placeholder="0101">
            <label class="form-label">Senha</label>
            <input class="form-control" name = "senha_cadastro" type="password" placeholder="password"><br>
            <div class="inline">
                <input type = "submit" value = "Cadastrar" name = "botao_cadastro1" class="btn btn-success">
                <a type="button" href="login.php" class="btn btn-primary">Logar-se</a>
            </div>
        </div>
    </form>
</div>    

    
    <script src="assets/bootstrap-5.3.3-dist/js/bootstrap.js"></script>
</body>
</html>

<?php

    if(isset($_POST["botao_cadastro1"])){
        if(isset($_POST["nome_cadastro"]) && !empty($_POST["nome_cadastro"])){

            $nome_cadastro = $_POST["nome_cadastro"];

            if(isset($_POST["senha_cadastro"]) && !empty($_POST["senha_cadastro"])){

                $senha_cadastro = $_POST["senha_cadastro"];

                if (isset($_POST["cep_cadastro"]) && !empty($_POST["cep_cadastro"])){        

                    $cep_cadastro = $_POST["cep_cadastro"];

                    if(isset($_POST["email"]) && !empty($_POST["email"])){

                        if(isset($_POST["numeracao_casa"]) && !empty($_POST["numeracao_casa"])){

                            $numeracao = $_POST["numeracao_casa"];

                            if (preg_match('/^\d{8}$/', $cep_cadastro)) {
                            

                            $banco = BDAcesso::getInstance();
                            $banco->inserirDados("Pessoas", "'$nome_cadastro', '$senha_cadastro', '$cep_cadastro', '$numeracao'", "nomePessoa, senhaPessoa, cepPessoa, numeracao");
                            
                            echo "Dados cadastrados!";

                            sleep(3);

                            header("Location: login.php");

                            }else{
                                echo "Numeração inválida ou não inserida";
                            }
                    }else{
                        echo "CEP inválido";
                    }

                }else{

                    echo "E-mail não inserido.";
                }
            }else{
                echo "Senha não inserida";
            }
        }else{
            echo "Nome não inserido";
        }
    }
}
?>